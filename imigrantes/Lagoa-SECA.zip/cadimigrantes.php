<?php
//$name = $_POST['nome'];
echo '$name';